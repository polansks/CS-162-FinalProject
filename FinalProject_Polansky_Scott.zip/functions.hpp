/****************************************************************
 ** File Name:      functions.hpp
 ** Author:         Scott Polansky
 ** Date:           Dec 5, 2017
 ** Description:    A random function
 ****************************************************************/

#ifndef functions_hpp
#define functions_hpp

#include <stdio.h>
#include <stdlib.h>

int randBetween(int, int);

#endif /* functions_hpp */
